<footer>


	<style type="text/css">
		
		/* Footer Styles */
		.footer{
		  width:100%;
		  padding:50px 0px;
		  background-color:black;
		  background-size:100% 100%;
		  text-align:center;
		}
		.footer i{
		color:#000;
		padding:10px;
		height:40px;
		font-size:20px;
		width:40px;
		margin:10px;
		border-radius:50%;
		background:#fff;
		transition:0.5s;
		}
		.footer i:hover.fa-facebook{
		background:#007bff;
		color:#fff;
		}
		.footer i:hover.fa-instagram{
		background:#fd375a;
		color:#fff;
		}
		.footer i:hover.fa-envelope{
		background:#cc8620;
		color:#fff;
		}
		.footer i:hover.fa-phone{
		background:#70412e;
		color:#fff;
		}
		.footer p{
		color:#fff;
		}
		.footer .fa-heart-o{
		color:#fd375a;
		background:none;
		}


	

	  

	 </style>

	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <div class="footer">
    <i class="fa fa-facebook"></i> <i class="fa fa-instagram"></i> <i class="fa fa-envelope"></i> <i class="fa fa-phone"></i>
    <p>© 2021 Shop mall || All rights reserved || Designed By: DGNR</p>
  </div>



</footer>